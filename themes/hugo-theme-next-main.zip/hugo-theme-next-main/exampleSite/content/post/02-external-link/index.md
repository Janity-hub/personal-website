---
title: "欢迎加入 Hugo NexT 组织！"
description: "Hugo NexT 是专门为 Hugo 引擎所打造的主题，保持简单易用和强大的功能！"
keywords: "Hugo,NexT,组织"

date: 2022-06-01T15:59:41+08:00
lastmod: 2022-06-01T15:59:41+08:00

categories:
 - 示例文章
tags:
 - Hugo
 - NexT

expand: true
extlink: https://gitee.com/hugo-next/hugo-theme-next/

weight: 1
---

欢迎来到 `Hugo NexT` 文档站点！ 它是从 [Theme NexT](https://theme-next.js.org/) 移植过来的为 [Hugo](https://gohugo.io/)打造的高品质优雅主题，保持简单易用的特性和强大的功能。



## 用户指南

设置 NexT 主题很容易。只需遵循文档，就可快速创建您的个人网站！

## 反馈

- 访问 Awesome NexT 列表，与其他用户分享插件和教程。
- 加入我们的 Gitter 聊天。
- 在几秒钟内添加或改进翻译。
- 在 GitHub Issues 中报告一个 :bug:。
- 在 GitHub 上申请一个新特性。
- 为最受欢迎的功能请求投票。

