---
title: "关于 Hugo NexT 组织"

date: 2022-06-09T20:12:52+08:00
lastmod: 2022-06-09T20:12:52+08:00

share: false
followme: false
nav: false
copyright: false
url: about.html
---

`Hugo NexT` 组织是由众多喜爱 `NexT` 主题及风格的世界各地友人共同组建而成，为的就是让这个主题继续在 `Hugo` 引擎中也能得到发扬光大，在此也欢迎你的加入！

# 我们的愿景

延续 `NexT` 经典的黑白调搭配，保持简单的易用性及强大的功能。

# 使用反馈

- 加入 [GitHub Discussions](https://github.com/hugo-next/hugo-theme-next/discussions) 或 [Gitter](https://gitter.im/hugo-next/community) 在线讨论 :beers:
- [GitHub Issues](https://github.com/hugo-next/hugo-theme-next/issues/new?labels=Bug&template=bug-report.md) 提交错误报告 :bug:
- [GitHub Feature](https://github.com/hugo-next/hugo-theme-next/issues/new?labels=Feature+Request&template=feature-request.md) 表新功能的想法 :sparkles:

> [!INFO]
> 同时国内用户也可加入 QQ 群交流： 604710815

{{< music url="/music/sky.mp3" name="天空之城" artist="宫崎骏" cover="/music/gongqijun.jpg" autoplay="true" >}}