---
title: "站点示例"
type: flinks
url: flinks.html
---

如想交换本站友情链接，请在评论区留下你的站点信息，格式参考如下：

```yaml
- name: Hugo-NexT
  desc: Hugo NexT 官方预览网站。
  avatar: https://hugo-next.eu.org/imgs/hugo_next_avatar.png
  link: https://hugo-next.eu.org
```