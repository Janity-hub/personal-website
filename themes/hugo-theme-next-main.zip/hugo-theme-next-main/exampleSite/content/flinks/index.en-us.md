---
title: "Demo Sites"
type: flinks
url: flinks.html
---

If you want to exchange friendly links on this site, please leave your site information in the comment section. The format reference is as follows:

```yaml
- name: Hugo-NexT
  desc: Hugo NexT Official Site.
  avatar: https://hugo-next.eu.org/imgs/hugo_next_avatar.png
  link: https://hugo-next.eu.org
```