---
name: 新功能请求(Feature Request)
about: Suggest an idea for this project
labels: feature request
---

请按照此新功能模版提供相关信息，如详细的功能描述或同类效果屏幕截图，这将有助于我们进行调查。
(Please follow this new feature template to provide relevant information, such as detail description for feature or some screenshots, which will help us investigate.)


## 新功能描述 (New feature description)


## 效果参考截图 (Screenshots if it possible)

