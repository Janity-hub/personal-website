---
title: 'Picture Shortcode Test'
date: 2020-06-04T23:30:14+02:00
Tags: [latin, medieval, picture]
Categories: [lorem, theme]
---

# Id Modi

Id modi explicabo non accusantium accusantium. Voluptates laborum est
exercitationem odit voluptate dicta laborum nemo. Dolorum et aliquam qui dolorem
voluptates ducimus voluptatibus. Quia sunt molestiae id ut. Necessitatibus
itaque sed unde sit repellendus sit. Error pariatur deserunt dignissimos saepe
cupiditate beatae.

{{< image frame="true" float="left" width="7em" caption="Nemo animi" src="img/thumbnails/hugo5.jpg" >}}

Illum quae laudantium quia vel facere aliquid earum. Inventore culpa
perspiciatis et veniam et amet distinctio. Facilis expedita doloremque
voluptates nihil et sint commodi et. Et totam iste doloribus et quisquam.
Quaerat veritatis repellendus vel est.

{{< image frame="true" float="right" width="9em" src="img/thumbnails/hugo2.jpg" >}}

Nemo animi expedita voluptas ut. Similique dolores animi aut similique vel ullam
aut. Numquam doloribus temporibus error cupiditate et et quia. Accusamus sunt et
omnis. Rem iure deserunt eaque. Corrupti autem reiciendis et temporibus et sit
ipsa.

Vero necessitatibus quasi id non assumenda saepe quaerat iusto. Assumenda quis
odio est et unde. Cumque necessitatibus aut suscipit sed molestiae. At doloribus
molestiae ut ratione.

Laudantium et perspiciatis error ut rem earum mollitia suscipit. Ut consectetur
voluptatem fugiat illum. Consequuntur quo non nam vitae similique voluptate
occaecati deleniti. Odio numquam sint expedita ratione. Natus magnam nemo enim
enim quasi consequuntur. Consectetur voluptatibus aut perspiciatis sint
similique.

Dignissimos aut sapiente inventore. Vero alias exercitationem sint mollitia
molestias dolorem aspernatur. Qui necessitatibus dolor ab ad a modi porro.

Quae qui ratione velit eaque iusto in omnis. Provident voluptatem qui ab
temporibus porro. Velit magnam vel totam laudantium voluptatem consequatur iste
dolores. Minima quia sapiente expedita dolorem et sit rerum.

Et odio asperiores et. Nesciunt adipisci quod distinctio perspiciatis. Enim
dignissimos error omnis cum rerum. Architecto est cumque sed. Optio et
perferendis et voluptatem et neque.

{{< image wide="true" caption="Vero necessitatibus" src="img/fullsize/hugo4.jpg" >}}

Adipisci repellat recusandae dolorem quam dolores quae dolor porro. Soluta sint
inventore dolores aut delectus quae. Eius est veniam vel nihil.

Voluptates facilis repudiandae explicabo optio quaerat quis consequuntur. Ullam
aspernatur expedita ea fuga consequuntur sit nam alias. Nisi quia laborum et
error tenetur accusamus aliquam. Harum tempore adipisci mollitia. Molestias
voluptatem consequuntur ipsum. Laboriosam earum voluptas et assumenda nemo qui.
