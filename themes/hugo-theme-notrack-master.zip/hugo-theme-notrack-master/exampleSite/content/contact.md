---
title: "Contact"
date: 2020-06-04T23:03:21+02:00
menu:
  main:
    name: "Contact"
    weight: 255
---

{{< contact-box >}}

To the right you see the `contact-box` shortcode demonstrated and
below is the `social` shortcode. Use which you like more or make your
own.

Repudiandae in pariatur voluptatibus inventore alias. Aut quasi non eos earum
odio maxime quo molestiae. Velit quidem magnam eos odit. Quisquam deleniti
officia quia. Harum dolorem est sed. Voluptas esse culpa molestias
exercitationem libero velit sunt hic.

{{< social >}}
