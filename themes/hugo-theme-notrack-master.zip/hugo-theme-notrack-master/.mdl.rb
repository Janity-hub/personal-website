all

exclude_rule "MD014"

exclude_rule "MD026"

exclude_rule "MD033"

rule "MD013", :tables => false
