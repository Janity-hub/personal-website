
---
title: "Welcome"
---

Welcome to my personal site! This is the homepage where you can find highlights of my insights, projects, and artwork.
